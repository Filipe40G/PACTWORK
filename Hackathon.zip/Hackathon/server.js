const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const port = 5500;
const { OpenAI } = require('langchain/llms/openai');

const llm = new OpenAI({
    openAIApiKey: "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",
  });

app.use(express.json());
app.use(cors());

app.post('/', async (req, res) => {

  let question = req.body;

  const llmResult = await llm.predict(question.question);

  res.send(llmResult)
});

// Start the server
app.listen(port, () => {
  console.log(`Server is listening at http://localhost:${port}`);
});
